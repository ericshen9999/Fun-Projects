Eric Shen (eshen3) (worked alone) - 
Checked for enemy turn during traverse
Added a check if the move wins a box, give it a higher weight